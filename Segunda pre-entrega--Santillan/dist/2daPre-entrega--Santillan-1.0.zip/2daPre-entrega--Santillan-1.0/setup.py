from setuptools import setup

setup(
    name="2daPre-entrega--Santillan", 
    version="1.0", 
    description="Este es mi primer paquete redistribuible",
    author="Lautaro Santillan", 
    author_email="santillanlautaro03@gmail.com"
)