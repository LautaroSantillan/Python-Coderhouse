from setuptools import setup

setup(name="paqueteSegundaEntrega", version="1.0", description="Este es mi primer paquete redistribuible",
author="Lautaro Santillan", author_email="santillanlautaro03@gmail.com")